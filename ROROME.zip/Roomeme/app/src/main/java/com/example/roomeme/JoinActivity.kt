package com.example.roomeme

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

class JoinActivity : AppCompatActivity() {

    private val TAG = "JoinActivity"
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_join)

        auth = Firebase.auth

        val email = findViewById<EditText>(R.id.btn_email)
        val pwd = findViewById<EditText>(R.id.btn_pw)

        val btn_join = findViewById<Button>(R.id.btn_join)
        btn_join.setOnClickListener {
            val userEmail = email.text.toString()
            val userPwd = pwd.text.toString()

            auth.createUserWithEmailAndPassword(userEmail, userPwd)
                .addOnCompleteListener(this) { task ->
                    if (task.isSuccessful) {
                        // 회원가입 성공
                        Log.d(TAG, "createUserWithEmail:success")
                        val user = auth.currentUser

                        // 이메일 확인 메일 보내기
                        user?.sendEmailVerification()
                            ?.addOnCompleteListener { verificationTask ->
                                if (verificationTask.isSuccessful) {
                                    // 이메일 확인 메일 전송 성공
                                    Toast.makeText(
                                        baseContext,
                                        "이메일 확인 메일이 전송되었습니다. 이메일을 확인해주세요.",
                                        Toast.LENGTH_SHORT
                                    ).show()

                                    // 회원가입에 성공했을 때 메인화면으로 이동하는 코드
                                    val intent = Intent(this@JoinActivity, MainActivity::class.java)
                                    startActivity(intent)
                                    finish()
                                } else {
                                    // 이메일 확인 메일 전송 실패
                                    Log.w(TAG, "sendEmailVerification:failure", verificationTask.exception)
                                    Toast.makeText(
                                        baseContext,
                                        "이메일 확인 메일 전송에 실패했습니다. 오류: ${verificationTask.exception?.message}",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            }
                    } else {
                        // 회원가입 실패
                        Log.w(TAG, "createUserWithEmail:failure", task.exception)
                        Toast.makeText(
                            baseContext,
                            "회원가입에 실패했습니다. 오류: ${task.exception?.message}",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
        }
    }
}
