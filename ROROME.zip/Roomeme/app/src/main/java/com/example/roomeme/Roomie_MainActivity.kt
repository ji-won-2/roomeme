package com.example.roomeme

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Roomie_MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_romie_main)
    }
}