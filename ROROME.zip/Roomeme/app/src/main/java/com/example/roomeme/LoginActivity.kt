package com.example.roomeme

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val btn_log = findViewById<Button>(R.id.btn_log)
        btn_log.setOnClickListener {
            Toast.makeText(this, "로그인 슝슝", Toast.LENGTH_LONG).show()
            val intent = Intent(this, Roomie_MainActivity::class.java)
            startActivity(intent)
        }
    }
}